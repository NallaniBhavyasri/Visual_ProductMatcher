import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

const App = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [similarProducts, setSimilarProducts] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setError('Please select a file to upload.');
      return;
    }

    setError(null);
    setLoading(true);

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      // Upload image to backend and get predictions
      const uploadResponse = await axios.post('http://localhost:5000/api/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      const uploadedImageUrl = uploadResponse.data.uploaded_image;
      setUploadedImage(uploadedImageUrl);

      // Get similar products (predictions) from CLIP API
      setSimilarProducts(uploadResponse.data.similar_products);
    } catch (err) {
      setError('Error processing the image. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <h1>Visual Product Matcher</h1>

      <div className="upload-section">
        <input type="file" onChange={handleFileChange} />
        <button onClick={handleUpload} disabled={loading}>
          {loading ? 'Uploading...' : 'Upload and Find Products'}
        </button>
        {error && <p className="error">{error}</p>}
      </div>

      {uploadedImage && (
        <div className="result-section">
          <h2>Uploaded Image:</h2>
          <img src={`http://localhost:5000/uploads/${uploadedImage}`} alt="Uploaded" className="uploaded-image" />

          <h2>Similar Products (CLIP Predictions):</h2>
          <div className="product-list">
            {similarProducts.map((product, index) => (
              <div key={index} className="product-card">
                <h3>{product.label}</h3>
                <p>Similarity Score: {product.score.toFixed(2)}%</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
